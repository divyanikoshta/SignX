import React from "react";
import classes from "./SignatureModal.module.css";

interface SignatureModalProp {
    children: any
    onConfirm: any
    onClose: any
    clearSignature: any
}

const SignatureModal = ({ children, onConfirm, onClose, clearSignature }: SignatureModalProp) => {
    return (
        <div className={classes['overlay-container']}>
            <div className={classes['dialogBox']}>
                <div id="header" className={classes['header']}>
                    <div>
                        Signature
                    </div>
                    <button onClick={onClose}>
                        X
                    </button>
                </div>
                <div onClick={clearSignature} className={classes['subheader']}>Clear Signature</div>
                <div id="body" className={classes['body']}>
                    {children}
                </div>
                <div id="footer" className={classes['footer']} >
                    <button onClick={onClose}>
                        Cancel
                    </button>
                    <button onClick={onConfirm}>
                        Confirm
                    </button>
                </div>
            </div>
        </div>
    )
};

export default SignatureModal;