import React from "react";
// import FILE from "../mock/samplefile";
import PdfViewHelper from "./PdfViewHelper";
import FILE from "../mock/sampleFile2";


const PdfViewer = () => {
    const pdfConfig = {
        scale: 1.5
    }
   
    return (
        <div>
            <PdfViewHelper fileAsBase64={FILE} pdfConfig={pdfConfig} />
        </div>
    )
};

export default PdfViewer;