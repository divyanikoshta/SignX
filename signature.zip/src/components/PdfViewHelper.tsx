import React, { useEffect, useRef, useState } from "react";
import ReactSignatureCanvas from "react-signature-canvas";
import { createPDFPage, getPDFDocument, renderPDFToCanvas } from "../utility/pdfViewerUtility";
import SignatureModal from "./SignatureModal/SignatureModal";
import styles from "./SignatureModal/SignatureModal.module.css";
import jsPDF from "jspdf";
import { PDFDocument } from "pdf-lib";
// import sign from "../mock/sampleSign";


interface sign {
    pos: {
        x: number,
        y: number,
        width: number,
        height: number,
    },
    signImage: string,
    pageNumber: number,
}


interface PdfViewHelper {
    fileAsBase64: string,
    pdfConfig: { scale: number }
}


const PdfViewHelper = ({ fileAsBase64, pdfConfig }: PdfViewHelper) => {
    const signRef: any = useRef(null);
    const containerRef: any = useRef(null);
    const [showOverlay, setShowOverlay] = useState(false)
    const [selectedSignBox, setSelectedSignBox] = useState<any>();
    const [boxes, setBoxes] = useState<any>([]);
    const [isAddingBox, setIsAddingBox] = useState(false);

    const dragItemIndex = useRef(null);
    const offset = useRef({ x: 0, y: 0 });

    const [modifiedPdf, setModifiedPdf] = useState<any>(null);

    const renderPdf = async () => {
        const binaryString = atob(fileAsBase64);
        const pdfDocument: any = await getPDFDocument(binaryString);
        let fullPdfContainer = document.getElementById("pdf-container");
        if (!fullPdfContainer) {
            console.error("Conatiner element not found.");
            return;
        }

        const pdfTotalPages = pdfDocument.numPages;
        for (let pageNumber = 1; pageNumber <= pdfTotalPages; pageNumber++) {
            const pdfPage = await createPDFPage(pdfDocument, pageNumber);
            const viewport = pdfPage.getViewport({ scale: pdfConfig.scale })
            const { height, width } = viewport;

            const perPageContainer = document.createElement("div");
            perPageContainer.style.position = "relative";
            perPageContainer.style.width = width + 'px';
            perPageContainer.style.height = height + 'px';
            perPageContainer.setAttribute("data-page-number", String(pageNumber));
            fullPdfContainer?.appendChild(perPageContainer);

            // create canvs for each page
            var canvas: any = document.createElement("canvas");
            canvas.height = height;
            canvas.width = width;
            const pdfPageCanvas = await renderPDFToCanvas(pdfPage, canvas, pdfConfig);
            perPageContainer?.appendChild(pdfPageCanvas);
        }
    }

    const hasMounted = useRef(false);
    const signArr = boxes.map((box: any) => box.sign).join(',');


    const onConfirm = () => {
        setShowOverlay(false);
        if (selectedSignBox) {
            const sign = signRef.current.getTrimmedCanvas().toDataURL('image/png');
            let signBox: any = document.getElementById(selectedSignBox)
            let selectedSignBoxInd = selectedSignBox.split("_");
            let signImgContainer = signBox?.getElementsByTagName("img");
            if (signImgContainer && signImgContainer[0]) {
                signImgContainer[0].src = sign;
                setBoxes((prev: any) => {
                    return prev.map((prevObj: any, index: number) => {
                        return index == selectedSignBoxInd[1] ? { ...prevObj, sign: sign } : { ...prevObj };
                    })
                })
            }
        }
    }


    useEffect(() => {
        if (!hasMounted.current) {
            hasMounted.current = true;
            return; // skip the first run
        }
        handleModifyPdf(boxes)
    }, [signArr]);

    const onClose = () => {
        setShowOverlay(false);
        clearSignature();
    }

    const clearSignature = () => {
        signRef.current.clear();
    }

    const handleModifyPdf = async (signBoxs: any) => {
        const existingPdfBase64 = fileAsBase64 // Your base64 PDF string here (without the "data:..." prefix)
        const pdfBytes = Uint8Array.from(atob(existingPdfBase64), c => c.charCodeAt(0));
        const pdfDoc = await PDFDocument.load(pdfBytes, { ignoreEncryption: true });

        const pages = pdfDoc.getPages();
        const firstPage = pages[0];
        const pageHeight = firstPage.getHeight();

        let pdfContainerStyle: any = document.getElementById('pdf-container')
        signBoxs.forEach(async (signBox: any, index: number) => {
            let imageBase64 = signBox.sign; // Your base64 image string (also without "data:image/png;base64,")

            let styles = document.getElementById(`signBox_${index}`)?.style;
            if (imageBase64 && styles) {
                imageBase64 = imageBase64.replace("data:image/png;base64,", "");
                const imageBytes = Uint8Array.from(atob(imageBase64), c => c.charCodeAt(0));
                const pngImage = await pdfDoc.embedPng(imageBytes);
                let newHeight = parseInt((styles.height.split("px"))[0]) * 0.75
                let newWidth = parseInt((styles.width.split("px"))[0]) * 0.75
                let newX = ((parseInt((styles.left.split("px"))[0]) - (window.innerWidth - pdfContainerStyle.clientWidth) / 2) * 0.75);
                // let newX = parseInt((styles.left.split("px"))[0]) / 1.5;
                let newY = (pageHeight - (parseInt((styles.top.split("px"))[0]) / 1.5) * 0.75);
                // let newY = pageHeight - ((parseInt((styles.top.split("px"))[0]) - parseInt((styles.height.split("px"))[0]) + 44) * 0.75);
                let page = pages[signBox.pageNumber - 1];
                console.log("newX--", newX)
                console.log("newY--", newY)
                page.drawImage(pngImage, {
                    x: newX,
                    y: newY,
                    width: newWidth, // image width on page
                    height: newHeight, // image height on page
                });
            }
        })


        const modifiedPdfBytes = await pdfDoc.save();
        let str = '';
        for (let i = 0; i < modifiedPdfBytes.length; i++) {
            str += String.fromCharCode(modifiedPdfBytes[i]);
        }

        const modifiedBase64 = btoa(str);
        setModifiedPdf(`data:application/pdf;base64,${modifiedBase64}`);
    };


    // const handleModifyPdf = async (sign: any, signBox: any, top: any, left: any, height: any, width: any) => {
    //     const existingPdfBase64 = fileAsBase64 // Your base64 PDF string here (without the "data:..." prefix)
    //     let imageBase64 = sign; // Your base64 image string (also without "data:image/png;base64,")
    //     imageBase64 = imageBase64.replace("data:image/png;base64,", "");
    //     // Convert base64 strings to Uint8Arrays
    //     const pdfBytes = Uint8Array.from(atob(existingPdfBase64), c => c.charCodeAt(0));
    //     const imageBytes = Uint8Array.from(atob(imageBase64), c => c.charCodeAt(0));

    //     // Load and edit the PDF
    //     const pdfDoc = await PDFDocument.load(pdfBytes, { ignoreEncryption: true });
    //     const pngImage = await pdfDoc.embedPng(imageBytes);
    //     const pages = pdfDoc.getPages();
    //     console.log("pages-->", pages)
    //     const firstPage = pages[signBox.getAttribute('data-page-number') - 1];
    //     const pageHeight = firstPage.getHeight();
    //     // Draw image at specific position

    //     let pdfContainerStyle: any = document.getElementById('pdf-container')
    //     let newHeight = parseInt((height.split("px"))[0]) * 0.75
    //     let newWidth = parseInt((width.split("px"))[0]) * 0.75
    //     let newX = ((parseInt((left.split("px"))[0]) - (window.innerWidth - pdfContainerStyle.clientWidth) / 2) * 0.75);
    //     let newY = pageHeight - ((parseInt((top.split("px"))[0]) - parseInt((height.split("px"))[0]) + 44) * 0.75);
    //     firstPage.drawImage(pngImage, {
    //         x: newX,
    //         y: newY,
    //         width: newWidth,
    //         height: newHeight,
    //     });


    //     const modifiedPdfBytes = await pdfDoc.save();
    //     let str = '';
    //     for (let i = 0; i < modifiedPdfBytes.length; i++) {
    //         str += String.fromCharCode(modifiedPdfBytes[i]);
    //     }

    //     const modifiedBase64 = btoa(str);
    //     setModifiedPdf(`data:application/pdf;base64,${modifiedBase64}`);
    // };

    const DownloadPdfButton = () => {
        // Remove the 'data:application/pdf;base64,' prefix
        if (modifiedPdf) {
            const base64String = modifiedPdf.replace(/^data:application\/pdf;base64,/, '');

            // Convert the Base64 string to a byte array
            const byteCharacters = atob(base64String); // atob() decodes the Base64 string into a binary string
            const byteArray = new Uint8Array(byteCharacters.length);

            // Fill the byte array with the decoded bytes
            for (let i = 0; i < byteCharacters.length; i++) {
                byteArray[i] = byteCharacters.charCodeAt(i);
            }

            // Create a Blob from the byte array (with mime type 'application/pdf')
            const blob = new Blob([byteArray], { type: 'application/pdf' });

            // Create a link to trigger the download
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);  // Create a temporary URL for the Blob
            link.download = "sample.pdf";  // Set the filename for the downloaded file

            // Trigger the click event to start the download
            link.click();
        }

    };

    useEffect(() => {
        renderPdf()
    }, []);

    const hanldeAddSignatureBox = () => {
        setIsAddingBox(true);
        document.body.style.cursor = 'crosshair';
    }

    const handleContainerClick = (e: any) => {
        if (!isAddingBox) return;
        const pageContainers = containerRef.current.querySelectorAll("[data-page-number]");
        for (let i = 0; i < pageContainers.length; i++) {
            const container = pageContainers[i];
            const rect = container.getBoundingClientRect();
            if (
                e.clientX >= rect.left &&
                e.clientX <= rect.right &&
                e.clientY >= rect.top &&
                e.clientY <= rect.bottom
            ) {
                const pageNumber = parseInt(container.getAttribute("data-page-number"));

                const x = e.pageX;
                const y = e.pageY;

                setBoxes([...boxes, { x, y, pageNumber, sign: '' }]);
                break;
            }
        }
        document.body.style.cursor = 'default';
        setIsAddingBox(false);
    };

    const handleMouseDown = (e: any, index: any) => {
        dragItemIndex.current = index;

        const box = boxes[index];
        offset.current = {
            x: e.pageX - box.x,
            y: e.pageY - box.y,
        };

        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
    };

    const handleMouseMove = (e: any) => {
        if (dragItemIndex.current === null) return;


        const containerRect = containerRef.current.getBoundingClientRect();
        const containerX = containerRect.left;
        const containerY = containerRect.top;

        // Mouse position relative to container
        let newX = e.pageX;
        let newY = e.pageY;

        const pageContainers = containerRef.current.querySelectorAll("[data-page-number]");
        let currentPageNumber = null;
        for (let i = 0; i < pageContainers.length; i++) {
            const pageRect = pageContainers[i].getBoundingClientRect();
            if (
                e.clientX >= pageRect.left &&
                e.clientX <= pageRect.right &&
                e.clientY >= pageRect.top &&
                e.clientY <= pageRect.bottom
            ) {
                currentPageNumber = parseInt(pageContainers[i].getAttribute("data-page-number"));
                break;
            }
        }

        // Clamp to keep box inside the container
        const maxX = containerRect.width + 100; // 100 = box width
        const maxY = containerRect.height;

        if (newY < containerY) {
            newY = containerY;
        } else if (newY > maxY) {
            newY = containerRect.height - 50;
        } else {
            newY = Math.max(0, Math.min(newY, maxY));
        }

        if (newX < ((window.innerWidth - containerRect.width) / 2)) {
            newX = (window.innerWidth - containerRect.width) / 2;
        } else {
            newX = Math.max(0, Math.min(newX, maxX));
        }

        const newBoxes = [...boxes];
        newBoxes[dragItemIndex.current] = {
            ...newBoxes[dragItemIndex.current],
            x: newX,
            y: newY,
            pageNumber: currentPageNumber ?? newBoxes[dragItemIndex.current].pageNumber, // fallback
        };

        setBoxes(newBoxes);
    };

    const handleMouseUp = () => {
        dragItemIndex.current = null;
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
    };

    const onBoxClick = (e: any) => {
        console.log("e -> ", e)
        if (e.target === e.currentTarget) {
            setShowOverlay(true)
            setSelectedSignBox(e.target.id);
        }
    }

    const onDelete = (ind: number) => {
        const newBoxes = [...boxes];
        newBoxes.splice(ind, 1);
        setBoxes(newBoxes);
    }

    return (
        <div>
            <div>
                <button onClick={DownloadPdfButton}>Download pdf</button>
            </div>
            <div>
                <button onClick={hanldeAddSignatureBox}>Add Signature Box</button>
            </div>
            <div style={{ display: 'flex', justifyContent: "center", background: "beige" }}>
                <div ref={containerRef} id="pdf-container" onClick={handleContainerClick} style={{ position: "relative" }}></div>
                {boxes?.map((box: any, index: number) => (
                    <div
                        id={"signBox_" + index}
                        key={index}
                        data-page-number={box.pageNumber}
                        style={{
                            position: 'absolute',
                            border: "2px dotted grey",
                            height: 100,
                            width: 200,
                            left: `${box.x}px`,
                            top: `${box.y}px`,
                            cursor: 'grab',
                        }}
                        onClick={(e) => onBoxClick(e)}
                        onMouseDown={(e) => handleMouseDown(e, index)}
                    >
                        <button
                            style={{
                                position: 'absolute',
                                top: '-27px',
                                right: '-2px',
                                color: 'black',
                                border: 'none',
                                borderRadius: '50%',
                                width: '20px',
                                height: '20px',
                                fontSize: '12px',
                                cursor: 'pointer',
                            }}
                            onClick={(e) => {
                                e.stopPropagation();
                                onDelete(index);
                            }}
                            title="Delete"
                        >
                            ×
                        </button>
                        <img id={"signImg_" + index} src={box.sign} height={80} />
                    </div>
                ))}
                {showOverlay && <SignatureModal onConfirm={onConfirm} onClose={onClose} clearSignature={clearSignature}>
                    <ReactSignatureCanvas
                        ref={signRef}
                        penColor="red"
                        minWidth={1.6}
                        canvasProps={{
                            className: styles.canvasSign
                        }}
                        // backgroundColor={"lightgray"}
                    />
                </SignatureModal>}

            </div>
            {modifiedPdf && (
                <iframe
                    title="Modified PDF"
                    src={modifiedPdf}
                    width="100%"
                    height="600px"
                    style={{ border: '1px solid black', marginTop: '20px' }}
                />
            )}
        </div >
    )
};

export default PdfViewHelper;